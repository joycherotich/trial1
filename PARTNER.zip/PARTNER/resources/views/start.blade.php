@include('topbar')
@include('sidebar')

<!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
    <!-- row -->
    <div class="container-fluid">

    <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item"><a href="#">Library</a></li>
                <li class="breadcrumb-item active" aria-current="page">Data</li>
            </ol>
    </nav>


        <div class="row">
            <!--**********************************
                    Start dynamic content
        ***********************************-->
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatem debitis vel impedit alias aliquid, saepe deleniti iste error perspiciatis a quo nisi iusto itaque incidunt nobis veniam hic voluptas ea.

            <!--**********************************
                    end dynamic content
        ***********************************-->

        </div>
    </div>
</div>
<!--**********************************
            Content body end
        ***********************************-->

@include('footer')