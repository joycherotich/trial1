<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>LIBERTY PORTAL</title>


    <link rel="icon" type="image/png" sizes="16x16" href="{{ asset('images/favicon.png') }}">

    <link href="{{ asset('libs/owl-carousel/owl.carousel.css') }}" rel="stylesheet">
    <link href="{{ asset('css/style.css') }}" rel="stylesheet">   
    <link href="{{ asset('css/LineIcons.css') }}" rel="stylesheet">

    <link href="{{ asset('css/imports.css') }}" rel="stylesheet">
    <link href="{{ asset('libs/icons/font-awesome-old/css/font-awesome.min.css') }}" rel="stylesheet">
    <script src="{{ asset('js/numeral.min.js') }}"></script>
    <link href="{{ asset('libs/jquery-steps/css/jquery.steps.css') }}" rel="stylesheet">