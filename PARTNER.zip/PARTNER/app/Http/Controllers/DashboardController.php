<?php

namespace App\Http\Controllers;
use customers;
use App\Models\Customer;
use CreatePaymentCyclesTable;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function dashboard()
  {
    $data['totalcustomers']=Customer::count();
    return view("dashboard", $data);
  } //close fxn   
  public function __invoke()
{
    return view("dashboard");
}


  

}
