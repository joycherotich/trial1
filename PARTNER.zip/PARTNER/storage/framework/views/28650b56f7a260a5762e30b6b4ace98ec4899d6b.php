<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>LIBERTY PORTAL</title>


    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('images/favicon.png')); ?>">

    <link href="<?php echo e(asset('libs/owl-carousel/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">   
    <link href="<?php echo e(asset('css/LineIcons.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('css/imports.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('libs/icons/font-awesome-old/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/numeral.min.js')); ?>"></script>
    <link href="<?php echo e(asset('libs/jquery-steps/css/jquery.steps.css')); ?>" rel="stylesheet"><?php /**PATH /home/joyletim/insurance/PARTNER/resources/views/includes/master.blade.php ENDPATH**/ ?>