<!-- resources/views/customers/customer.blade.php -->



<?php $__env->startSection('content'); ?>
    <div class="customer-details-container">
        <h1>Customer Details</h1>

        
        <div class="customer-details">
            <p><strong>ID:</strong> <?php echo e($customer->id); ?></p>
            <p><strong>Name:</strong> <?php echo e($customer->name); ?></p>
            <p><strong>Email:</strong> <?php echo e($customer->email); ?></p>
            <p><strong>Phone Number:</strong> <?php echo e($customer->phone_number); ?></p>
            <p><strong>ID Number:</strong> <?php echo e($customer->id_number); ?></p>
        </div>

        <hr>

        <a href="<?php echo e(route('customers.index')); ?>" class="back-link">Back to Customers</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        /* Add your custom styles here */
        .customer-details-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 5px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .customer-details {
            margin-bottom: 20px;
        }

        .back-link {
            display: inline-block;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .back-link:hover {
            background-color: #0056b3;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/joyletim/insurance/PARTNER/resources/views//customer/customer.blade.php ENDPATH**/ ?>